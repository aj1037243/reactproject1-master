import React from "react";
import './css/About.css';

const About = props => (
    <div className="about-page">
        <h1>Meet our Contributors</h1>
        <ul>
            <li><b>Aaronweber Jodesty</b></li>
            <li><b>Spencer Skaggs</b></li>
            <li><b>Jonas Lee</b></li>
        </ul>
    </div>
);

export default About;